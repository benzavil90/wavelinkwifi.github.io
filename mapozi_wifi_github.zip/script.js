// Small entrance animation for the payment-success page.
document.addEventListener("DOMContentLoaded", () => {
  const box = document.querySelector(".success-box");
  box.animate(
    [
      { opacity: 0, transform: "translateY(18px)" },
      { opacity: 1, transform: "translateY(0)" }
    ],
    { duration: 550, easing: "ease-out", fill: "forwards" }
  );
});
