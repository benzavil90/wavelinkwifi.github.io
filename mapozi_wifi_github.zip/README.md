# Mapozi WiFi Payment Success Page

A responsive static HTML/CSS/JavaScript recreation of the Mapozi WiFi payment-success screen.

## Files

- `index.html` — page structure
- `style.css` — responsive styling and animated star
- `script.js` — entrance animation

## Customize

1. Change the Internet destination in `index.html`:
   `href="http://neverssl.com/"`
2. Change the phone number if needed.
3. For the exact Mapozi logo, replace the CSS logo area with your own image, e.g.:
   `<img src="logo.png" alt="Mapozi WiFi">`

## GitHub Pages

Put these files in the root of a GitHub repository and enable GitHub Pages from the repository's Pages settings. GitHub Pages can publish static HTML, CSS and JavaScript files directly from a repository.
